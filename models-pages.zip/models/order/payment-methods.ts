export enum PaymentMethods {
    CASH = 'Payement à la livraison',
    CHEQUE = 'Chèque'
}
