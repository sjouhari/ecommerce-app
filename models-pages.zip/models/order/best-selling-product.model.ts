export interface BestSellingProduct {
    totalSold: number;
    productId: number;
    productName: string;
    productImage: string;
}
