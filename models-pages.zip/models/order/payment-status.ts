export enum PaymentStatus {
    PENDING = 'En Attente',
    PAID = 'Payé',
    CANCELLED = 'Annulé'
}
