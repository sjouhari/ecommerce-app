export interface TopSellingStore {
    storeId: number;
    storeName: string;
    totalSold: number;
}
