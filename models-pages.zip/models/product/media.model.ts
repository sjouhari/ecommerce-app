export interface Media {
    id: number;
    url: string;
    altText: string;
}
