export enum ProductColor {
    ROUGE = '#ff0000',
    VERT = '#00ff00',
    BLEU = '#0000ff',
    JAUNE = '#ffff00',
    NOIR = '#000000',
    BLANC = '#ffffff',
    GRIS = '#808080',
    ROSE = '#ff00ff',
    ORANGE = '#ff8000',
    MARRON = '#800000',
    VIOLET = '#800080'
}
