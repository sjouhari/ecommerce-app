export interface TVA {
    id: number;
    name: string;
    value: number;
}
