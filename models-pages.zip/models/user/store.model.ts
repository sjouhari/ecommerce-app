export interface Store {
    id: number;
    name: string;
    address: string;
    phoneNumber: string;
    email: string;
    userId: number;
}
