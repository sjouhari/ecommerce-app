export interface Feature {
    id?: number;
    libelle: string;
    resourceName: string;
    action: string;
}
