export enum Profils {
    ROLE_USER = 'Utilisateur',
    ROLE_SELLER = 'Vendeur',
    ROLE_ADMIN = 'Administrateur'
}
