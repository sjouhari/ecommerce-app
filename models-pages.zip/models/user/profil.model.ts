import { Feature } from './feature.model';

export interface Profil {
    id: number;
    name: string;
    features: Feature[];
}
