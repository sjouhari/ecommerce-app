package com.ecommerce.order.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CashDto extends PaymentMethodDto {

}
