package com.ecommerce.order.dto;

public interface TopSellersProjection {

    Long getStoreId();

    Long getTotalSold();

}
