package com.ecommerce.order.dto;

public interface BestSellingProductProjection {

    Long getProductId();

    Long getTotalSold();

}
