package com.ecommerce.order.enums;

public enum PaymentMethods {
    CASH,
    CHEQUE
}
