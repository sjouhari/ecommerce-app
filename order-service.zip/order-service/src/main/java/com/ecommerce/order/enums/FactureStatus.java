package com.ecommerce.order.enums;

public enum FactureStatus {
    PAID, UNPAID
}
