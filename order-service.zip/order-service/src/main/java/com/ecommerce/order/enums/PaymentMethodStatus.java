package com.ecommerce.order.enums;

public enum PaymentMethodStatus {
    PENDING,
    PAID,
    CANCELLED
}
